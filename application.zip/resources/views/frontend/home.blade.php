@extends('frontend.layout.layout')
@section('content')
    <!-- Header-Area-Start -->
    @include('frontend.section.hero')
    <!-- Header-Area-End -->

    <!-- Service-Area-Start -->
    @include('frontend.section.Service')
    <!-- Service-Area-End -->

    <!-- Service-Area-Start -->
    @include('frontend.section.about')
    <!-- About-Area-End -->

    <!-- Portfolio-Area-Start -->
    @include('frontend.section.Portfolio')
    <!-- Portfolio-Area-End -->

    <!-- Skills-Area-Start -->
    @include('frontend.section.Skill')
    <!-- Skills-Area-End -->

    <!-- Experience-Area-Start -->
    @include('frontend.section.Experience')
    <!-- Experience-Area-End -->

    <!-- Testimonial-Area-Start -->
    @include('frontend.section.Testimonial')
    <!-- Testimonial-Area-End -->

    <!-- Blog-Area-Start -->
    @include('frontend.section.Blog')
    <!-- Blog-Area-End -->

    <!-- Contact-Area-Start -->
    @include('frontend.section.Contact')
    <!-- Contact-Area-End -->
@endsection
